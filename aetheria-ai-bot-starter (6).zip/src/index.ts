import {
  Client, Events, GatewayIntentBits, ChatInputCommandInteraction
} from "discord.js";
import OpenAI from "openai";
import { config } from "./config.js";
import { handleCommand } from "./commands.js";

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});
const openai = new OpenAI({ apiKey: config.openaiApiKey });

function clip(text: string): string {
  const cleaned = text.replace(/@everyone/g, "@ everyone").replace(/@here/g, "@ here").trim();
  return cleaned.length > config.maxReplyChars
    ? `${cleaned.slice(0, config.maxReplyChars - 20)}\n\n[Reply shortened]`
    : cleaned;
}

async function getAnswer(instructions: string, input: string): Promise<string> {
  const result = await openai.responses.create({
    model: config.openaiModel,
    instructions,
    input
  });
  return clip(result.output_text || "I couldn't generate a response. Please try again.");
}

client.once(Events.ClientReady, readyClient => {
  console.log(`Ready as ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const command = interaction as ChatInputCommandInteraction;

  if (config.aiChannelId && ["ask", "summarize", "translate"].includes(command.commandName)
      && command.channelId !== config.aiChannelId) {
    await command.reply({
      content: "Please use the configured Bot command channel for this command.",
      ephemeral: true
    });
    return;
  }

  try {
    if (command.commandName === "ask") {
      await command.deferReply();
      const question = command.options.getString("question", true);
      const answer = await getAnswer(
        "You are Aetheria AI, a helpful, respectful assistant for an anime and general-interest community. Be clear and concise. Do not claim certainty when unsure. Do not request passwords, API keys, or unnecessary personal data. Keep content appropriate for a mixed-age community.",
        question
      );
      await command.editReply(answer);
      return;
    }

    if (command.commandName === "summarize") {
      await command.deferReply();
      const source = command.options.getString("text", true);
      const answer = await getAnswer(
        "Summarize the user's supplied text accurately. Preserve important facts and uncertainty. Do not invent details.",
        source
      );
      await command.editReply(answer);
      return;
    }

    if (command.commandName === "translate") {
      await command.deferReply();
      const language = command.options.getString("language", true);
      const source = command.options.getString("text", true);
      const answer = await getAnswer(
        `Translate the supplied text into ${language}. Preserve meaning and tone. Output the translation only unless a brief clarification is essential.`,
        source
      );
      await command.editReply(answer);
      return;
    }

    await handleCommand(command);
  } catch (error) {
    console.error("Command failed:", error instanceof Error ? error.message : "Unknown error");
    const message = "That command failed. Please try again later.";
    if (command.deferred || command.replied) {
      await command.followUp({ content: message, ephemeral: true }).catch(() => undefined);
    } else {
      await command.reply({ content: message, ephemeral: true }).catch(() => undefined);
    }
  }
});

process.on("unhandledRejection", reason => {
  console.error("Unhandled rejection:", reason instanceof Error ? reason.message : "Unknown error");
});

await client.login(config.discordToken);