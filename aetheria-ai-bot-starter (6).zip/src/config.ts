import "dotenv/config";

function required(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export const config = {
  discordToken: required("DISCORD_TOKEN"),
  discordClientId: required("DISCORD_CLIENT_ID"),
  discordGuildId: process.env.DISCORD_GUILD_ID?.trim() || "",
  openaiApiKey: required("OPENAI_API_KEY"),
  openaiModel: process.env.OPENAI_MODEL?.trim() || "gpt-4.1-mini",
  aiChannelId: process.env.AI_CHANNEL_ID?.trim() || "",
  maxReplyChars: Math.min(1900, Math.max(500, Number(process.env.MAX_REPLY_CHARS || 1800)))
};