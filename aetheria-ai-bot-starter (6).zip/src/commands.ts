import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  PermissionFlagsBits
} from "discord.js";

export const commandDefinitions = [
  new SlashCommandBuilder()
    .setName("ask")
    .setDescription("Ask Aetheria's AI assistant a question.")
    .addStringOption(option =>
      option.setName("question").setDescription("What would you like help with?")
        .setRequired(true).setMaxLength(1500)),
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check whether Aetheria AI is online."),
  new SlashCommandBuilder()
    .setName("summarize")
    .setDescription("Summarize text you provide.")
    .addStringOption(option =>
      option.setName("text").setDescription("Text to summarize")
        .setRequired(true).setMaxLength(3500)),
  new SlashCommandBuilder()
    .setName("translate")
    .setDescription("Translate text into a language you choose.")
    .addStringOption(option =>
      option.setName("language").setDescription("Target language, e.g. Japanese")
        .setRequired(true).setMaxLength(60))
    .addStringOption(option =>
      option.setName("text").setDescription("Text to translate")
        .setRequired(true).setMaxLength(2500)),
  new SlashCommandBuilder()
    .setName("botinfo")
    .setDescription("Show basic information about Aetheria AI.")
].map(command => command.toJSON());

export async function handleCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  if (interaction.commandName === "ping") {
    await interaction.reply({ content: "Aetheria AI is online.", ephemeral: true });
    return;
  }
  if (interaction.commandName === "botinfo") {
    await interaction.reply({
      content: "Aetheria AI is the community assistant for Aetheria. Use /ask, /summarize, or /translate. Do not share passwords, private information, or API keys.",
      ephemeral: true
    });
    return;
  }
  // AI command processing is implemented in index.ts.
}