# Aetheria AI

A Discord AI bot for the Aetheria community, built with TypeScript, discord.js, and the OpenAI API.

## Commands
- `/ask question:` Ask the AI a question.
- `/summarize text:` Summarize supplied text.
- `/translate text: language:` Translate text.
- `/ping` Check bot responsiveness.
- `/botinfo` Show basic bot configuration.

## Required setup
1. Create a Discord application and bot in the official Discord Developer Portal.
2. Invite it with the `bot` and `applications.commands` OAuth scopes. Grant only the permissions it needs: View Channels, Send Messages, Read Message History, and Use Slash Commands. Do not grant Administrator.
3. Create an OpenAI API key and set a usage budget.
4. Set these environment variables in Railway (never commit a real `.env` file):
   - `DISCORD_TOKEN`
   - `DISCORD_CLIENT_ID`
   - `DISCORD_GUILD_ID` (recommended for initial testing)
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL` (optional; defaults to `gpt-4.1-mini`)
   - `AI_CHANNEL_ID` (optional; restrict AI commands to one channel)
5. Deploy the repository on Railway. The app registers its slash commands on startup.

## Important
This bot does not automatically redesign an existing Discord server, create roles/channels, or provide a full moderation suite. Those tasks require separate configuration and appropriate bot permissions. Keep secrets in Railway Variables, never in source control or chat. Test in a private channel first.
