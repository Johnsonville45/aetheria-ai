import OpenAI from "openai";
import {
  Client,
  Events,
  GatewayIntentBits,
  MessageFlags,
  REST,
  Routes,
} from "discord.js";
import { config } from "./config.js";
import { commandDefinitions } from "./commands.js";

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const ai = new OpenAI({ apiKey: config.openAiApiKey });

async function registerCommands(): Promise<void> {
  const rest = new REST({ version: "10" }).setToken(config.discordToken);
  const route = config.discordGuildId
    ? Routes.applicationGuildCommands(config.discordClientId, config.discordGuildId)
    : Routes.applicationCommands(config.discordClientId);
  await rest.put(route, { body: commandDefinitions });
  console.log(`Registered slash commands ${config.discordGuildId ? "for the configured server" : "globally"}.`);
}

async function askAi(prompt: string): Promise<string> {
  const response = await ai.responses.create({
    model: config.openAiModel,
    input: prompt,
    max_output_tokens: 700,
  });
  return response.output_text?.trim() || "I couldn't generate a response this time.";
}

client.once(Events.ClientReady, readyClient => {
  console.log(`Ready as ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (config.aiChannelId && interaction.channelId !== config.aiChannelId &&
      !["ping", "botinfo"].includes(interaction.commandName)) {
    await interaction.reply({
      content: `Please use AI commands in <#${config.aiChannelId}>.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  try {
    if (interaction.commandName === "ping") {
      await interaction.reply({ content: "Pong. Aetheria AI is online.", flags: MessageFlags.Ephemeral });
      return;
    }

    if (interaction.commandName === "botinfo") {
      await interaction.reply({
        content: `Aetheria AI\nModel: ${config.openAiModel}\nAI channel restriction: ${config.aiChannelId ? "enabled" : "not configured"}`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply();
    let prompt: string;

    if (interaction.commandName === "ask") {
      prompt = interaction.options.getString("question", true);
    } else if (interaction.commandName === "summarize") {
      prompt = `Summarize the following text clearly and accurately. Do not invent details:\n\n${interaction.options.getString("text", true)}`;
    } else if (interaction.commandName === "translate") {
      const text = interaction.options.getString("text", true);
      const language = interaction.options.getString("language", true);
      prompt = `Translate the following text into ${language}. Return only the translation unless a brief clarification is essential:\n\n${text}`;
    } else {
      await interaction.editReply("Unknown command.");
      return;
    }

    const answer = await askAi(prompt);
    const chunks = answer.match(/[\s\S]{1,1900}/g) ?? ["No response."];
    await interaction.editReply(chunks[0]);
    for (const chunk of chunks.slice(1, 5)) {
      await interaction.followUp({ content: chunk });
    }
  } catch (error) {
    console.error("Interaction failed:", error instanceof Error ? error.message : "Unknown error");
    const message = "Sorry, that request failed. Please try again later.";
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({ content: message, flags: MessageFlags.Ephemeral }).catch(() => undefined);
    } else {
      await interaction.reply({ content: message, flags: MessageFlags.Ephemeral }).catch(() => undefined);
    }
  }
});

await registerCommands();
await client.login(config.discordToken);
