import { SlashCommandBuilder } from "discord.js";

export const commandDefinitions = [
  new SlashCommandBuilder()
    .setName("ask")
    .setDescription("Ask Aetheria AI a question")
    .addStringOption(o => o.setName("question").setDescription("Your question").setRequired(true).setMaxLength(4000)),
  new SlashCommandBuilder()
    .setName("summarize")
    .setDescription("Summarize text with Aetheria AI")
    .addStringOption(o => o.setName("text").setDescription("Text to summarize").setRequired(true).setMaxLength(8000)),
  new SlashCommandBuilder()
    .setName("translate")
    .setDescription("Translate text with Aetheria AI")
    .addStringOption(o => o.setName("text").setDescription("Text to translate").setRequired(true).setMaxLength(4000))
    .addStringOption(o => o.setName("language").setDescription("Target language, e.g. English or Japanese").setRequired(true).setMaxLength(80)),
  new SlashCommandBuilder().setName("ping").setDescription("Check whether the bot is responding"),
  new SlashCommandBuilder().setName("botinfo").setDescription("Show Aetheria AI bot information"),
].map(command => command.toJSON());
